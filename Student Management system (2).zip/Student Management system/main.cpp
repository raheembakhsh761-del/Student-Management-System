#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sstream>


using namespace std;

struct subject // declared nested structure
{
    float QCR;
    float ENA;
    float FE;
    float PHY;
    float CIVIC;
    float DF;
    float total;
    float percentage;

};

struct Student//structure for student enter
{
    int id;
    string name;
    int age;
    subject mark;
    string grade;
    float gpa;
};

void displayMenu() //function to give sms to user perform varius function
{
    cout << endl;
    cout << "---------------Student Management System Menu------------------\n";
    cout << endl;
    cout << "1. Add New Student\n";
    cout << "2. Calculate Student GPA\n";
    cout << "3. Display Student Information\n";
    cout << "4. Generate report\n ";
    cout << "5. disply report on console\n";
    cout << "6. disply student result on the base of id:\n";
    cout << "7. Exit\n";
    cout << endl;
    cout << "---------------------------------------------------------------\n";
    cout << endl;
    cout << "Enter your choice: ";
    cout << endl;
}

string calculateGrade(float a) //function to calculate grade on the base of percentage
{
    if (a >= 90)
    {
        return "A+";
    }
    else if (a >= 80)
    {
        return "A";
    }
    else if (a >= 70)
    {
        return "B+";
    }
    else if (a >= 60)
    {
        return "B";
    }
    else if (a >= 50)
    {
        return "C+";
    }
    else if (a >= 40)
    {
        return "C";
    }
    else
    {
        return "F";
    }
}


float gradeToGPA(string grade)// The to calculate gpa on the base of grade
{
    if (grade == "A+")
        return 4.0;
    else if (grade == "A")
        return 3.7;
    else if (grade == "B+")
        return 3.3;
    else if (grade == "B")
        return 3.0;
    else if (grade == "C+")
        return 2.7;
    else if (grade == "C")
        return 2.0;
    else
        return 0.0;
}


void addStudent(Student &newStudent, ofstream &outFile)// the that use to add student
{
    cout << "Enter student ID: ";
    cin >> newStudent.id;
    cin.ignore(); // To clear the newline character from the input buffer
    cout << "Enter student name: ";
    getline(cin, newStudent.name);
    cout << "Enter student age: ";
    cin >> newStudent.age;
    cin.ignore();
    cout << "Enter mark of QCR: ";
    cin >> newStudent.mark.QCR;
    cout << "Enter mark of ENA: ";
    cin >> newStudent.mark.ENA;
    cout << "Enter mark of FE: ";
    cin >> newStudent.mark.FE;
    cout << "Enter mark of PHY: ";
    cin >> newStudent.mark.PHY;
    cout << "Enter mark of CIVIC: ";
    cin >> newStudent.mark.CIVIC;
    cout << "Enter mark of DF: ";
    cin >> newStudent.mark.DF;

    newStudent.mark.total = newStudent.mark.QCR + newStudent.mark.ENA + newStudent.mark.FE + newStudent.mark.PHY + newStudent.mark.CIVIC + newStudent.mark.DF;
    newStudent.mark.percentage = (newStudent.mark.total / 600) * 100;// calculate percentage the marks of student
    newStudent.grade = calculateGrade(newStudent.mark.percentage);

    outFile << newStudent.id << "," << newStudent.name << "," << newStudent.age << ","  //the student data store in file
            << newStudent.mark.QCR << "," << newStudent.mark.ENA << ","
            << newStudent.mark.FE << ","
            << newStudent.mark.PHY << "," << newStudent.mark.CIVIC << ","
            << newStudent.mark.DF << ","
            << newStudent.mark.total << "," << newStudent.mark.percentage << ","
            << newStudent.grade << "\n";
    outFile.close();

    cout << "Student added successfully." << endl;
}



void displayStudents()
{
    ifstream inFile("outFile.csv");
    if (!inFile.is_open())
    {
        cout << "Error: Unable to open the file." << endl;
        return;
    }
    cout<<"----------------------------------------The whole data of student that is Register in file------------------------------------------------\n\n";


    cout << left << setw(10) << "ID" << setw(20) << "Name" << setw(5) << "Age" << setw(10) << "QCR"
         << setw(10) << "ENA" << setw(10) << "FE" << setw(10) << "PHY" << setw(10) << "CIVIC"
         << setw(10) << "DF" << setw(10) << "Total" << setw(15) << "Percentage" << setw(10) << "Grade" << setw(20) <<"GPA"<< endl;
    cout << endl;
    string line;
    while (getline(inFile, line))
    {
        // Read the entire content of the file into a string buffer
        stringstream ss(line);
        string id, name, age, QCR, ENA, FE, PHY, CIVIC, DF, total, percentage, grade,gpa;
        getline(ss, id, ',');
        getline(ss, name, ',');
        getline(ss, age, ',');
        getline(ss, QCR, ',');
        getline(ss, ENA, ',');
        getline(ss, FE, ',');
        getline(ss, PHY, ',');
        getline(ss, CIVIC, ',');
        getline(ss, DF, ',');
        getline(ss, total, ',');
        getline(ss, percentage, ',');
        getline(ss, grade, ',');
        getline(ss, gpa, ',');

        cout << left << setw(10) << id << setw(20) << name << setw(5) << age << setw(10) << QCR
             << setw(10) << ENA << setw(10) << FE << setw(10) << PHY << setw(10) << CIVIC
             << setw(10) << DF << setw(10) << total << setw(15) << percentage << setw(10) << grade <<setw(20)<<gpa<< endl;
    }
    cout << endl;
    cout <<"-------------------------------------------------------------------------------------------------------------------------------------------\n\n";

    inFile.close();
}


void displayStudentsid()
{
    ifstream inFile("outFile.csv");
    if (!inFile.is_open())
    {
        cout << "Error: Unable to open the file." << endl;
        return;
    }

    string line;
    int num1;

    // Prompt user for ID input
    cout << "Enter the student ID (enter a negative integer to stop): ";
    cin >> num1;

    while (num1 >= 0) // Loop until user enters a negative integer
    {
        bool found = false;

        // Reset file stream to the beginning
        inFile.clear(); // Clear any error flags  //help from google
        inFile.seekg(0, ios::beg); // Move to the beginning of the file

        // Read each line from the file
        while (getline(inFile, line))
        {
            stringstream ss(line);
            string id, name, age, QCR, ENA, FE, PHY, CIVIC, DF, total, percentage, grade, gpa;


            getline(ss, id, ',');
            getline(ss, name, ',');
            getline(ss, age, ',');
            getline(ss, QCR, ',');
            getline(ss, ENA, ',');
            getline(ss, FE, ',');
            getline(ss, PHY, ',');
            getline(ss, CIVIC, ',');
            getline(ss, DF, ',');
            getline(ss, total, ',');
            getline(ss, percentage, ',');
            getline(ss, grade, ',');
            getline(ss, gpa, ',');

            // Convert id from string to integer for comparison
            int studentID = stoi(id);

            // Check if the current student ID matches the input ID
            if (num1 == studentID)
            {
                cout << endl;
                // Display student information
                cout << "***** Student Information *****" << endl;
                cout << "ID: " << id << endl;
                cout << "Name: " << name << endl;
                cout << "Age: " << age << endl;
                cout << "QCR: " << QCR << endl;
                cout << "ENA: " << ENA << endl;
                cout << "FE: " << FE << endl;
                cout << "PHY: " << PHY << endl;
                cout << "CIVIC: " << CIVIC << endl;
                cout << "DF: " << DF << endl;
                cout << "Total: " << total << endl;
                cout << "Percentage: " << percentage << endl;
                cout << "Grade: " << grade << endl;
                cout << "GPA: " << gpa << endl;
                cout << endl;
                cout << "******************" << endl << endl;

                found = true;
                break; // Stop searching after finding the student
            }
        }

        if (!found)
        {
            cout << "No student found with ID: " << num1 << endl;
        }

        // Prompt user again for ID input
        cout << "Enter another student ID (enter a negative integer to stop): ";
        cin >> num1;
    }
}

void calculateStudentGPA(Student Student) // function use to cal culculate gpa
{

    {
        ifstream inFile("outFile.csv");
        if (!inFile)
        {
            cout << "file is not open " << endl;
            return;
        }

        stringstream buffer;   //these  four lines are taken from google
        buffer << inFile.rdbuf();
        string fileContent = buffer.str();
        inFile.close();

        ofstream outFile("outFile.csv", ios::trunc);
        if (!outFile.is_open())
        {
            cout << "Error: Unable to open the file for writing." << endl;
            return;
        }

        stringstream ss(fileContent);
        string line;

        while (getline(ss, line))
        {
            stringstream lineStream(line);
            string id, name, age, QCR, ENA, FE, PHY, CIVIC, DF, total, percentage, grade ;

            getline(lineStream, id, ',');
            getline(lineStream, name, ',');
            getline(lineStream, age, ',');
            getline(lineStream, QCR, ',');
            getline(lineStream, ENA, ',');
            getline(lineStream, FE, ',');
            getline(lineStream, PHY, ',');
            getline(lineStream, CIVIC, ',');
            getline(lineStream, DF, ',');
            getline(lineStream, total, ',');
            getline(lineStream, percentage, ',');
            getline(lineStream, grade, ',');

            Student.gpa= gradeToGPA(grade);

            outFile << id << "," << name << "," << age << "," << QCR << "," << ENA << "," << FE << ","
                    << PHY << "," << CIVIC << "," << DF << "," << total << "," << percentage << ","
                    << grade << "," << Student.gpa << "\n";

        }
        cout<<"The GPA is calculated and store in the file\n";

        outFile.close();
    }
}


void gernatereport()
{
    cout<<endl;
    cout<<endl;
    ofstream my_file("report.txt");
    if (!my_file.is_open())
    {
        cout << "Error: Unable to open the file for writing." << endl;
        return;
    }
    string date;
    cout<<"enter today date"<<endl;
    getline(cin,date);
    cin.ignore();
    ifstream inFile("outFile.csv");
    if (!inFile.is_open())
    {
        cout << "Error: Unable to open the file." << endl;
        return;
    }
    float avergegpa=0;
    int count1=0;
    float arr[100]= {0};
    stringstream buffer;        //these four line are copies from  Google
    buffer << inFile.rdbuf();
    string fileContent = buffer.str();
    inFile.close();

    ofstream outFile("outFile.csv", ios::trunc);
    if (!outFile.is_open())
    {
        cout << "Error: Unable to open the file for writing." << endl;
        return;
    }

    stringstream ss(fileContent);
    string line;

    while (getline(ss, line))
    {
        stringstream lineStream(line);
        string id, name, age, QCR, ENA, FE, PHY, CIVIC, DF, total, percentage, grade ;

        getline(lineStream, id, ',');
        getline(lineStream, name, ',');
        getline(lineStream, age, ',');
        getline(lineStream, QCR, ',');
        getline(lineStream, ENA, ',');
        getline(lineStream, FE, ',');
        getline(lineStream, PHY, ',');
        getline(lineStream, CIVIC, ',');
        getline(lineStream, DF, ',');
        getline(lineStream, total, ',');
        getline(lineStream, percentage, ',');
        getline(lineStream, grade, ',');

        float gpa= gradeToGPA(grade);

        outFile << id << "," << name << "," << age << "," << QCR << "," << ENA << "," << FE << ","
                << PHY << "," << CIVIC << "," << DF << "," << total << "," << percentage << ","
                << grade << "," << gpa << "\n";
        avergegpa+=gpa;
        arr[count1]=gpa;
        count1++;

    }

    outFile.close();

    cout << "------------------------------------------ Student  Report -------------------------------------------" << endl;
    cout << endl;
    my_file<<" Student  Report\n\n";

    my_file<<" Title: Student GPA Report \n\n";
    my_file<<" Institution Name: Namal University Miawali\n";
    my_file<<" Academic Semester: Spring 2024\n";

    my_file<<" Date of Report: ";
    my_file<<date<<endl;
    my_file<<" Prepared by: Raheem Bakhsh\n";

    my_file<<" Table of Contents\n";
    my_file<<" 1. Introduction\n";
    my_file<<" 2. Summary of GPA Statistics\n";
    my_file<<" 4. Conclusion\n";

    my_file<<"--------------------- Introduction ----------------------\n\n";
    my_file<<" The purpose of this report is to provide an \n";
    my_file<<" overview of student academic performance based on their GPAs \n";
    my_file<<" for the Fall 2024 semester. GPA is a critical indicator of student\n";
    my_file<<" success and helps in identifying both high achievers and those who\n ";
    my_file<<" may need additional support.\n\n";

    my_file<<"--------------- Summary of GPA Statistics ---------------\n\n";
    float maxgpa = arr[0];

    // Traverse the array to find the maximum element
    for(int i = 0; i <=count1-1; i++)
    {
        if(arr[i] > maxgpa)
        {
            maxgpa = arr[i];
        }
    }
    my_file<<" Maximum GPA: ";
    my_file<<maxgpa<<endl;
    float mingpa = arr[0];

    // Traverse the array to find the maximum element
    for(int i = 0; i <=count1-1; i++)
    {
        if(arr[i] < mingpa)
        {
            mingpa = arr[i];
        }

    }
    my_file<<" Lowest GPA: ";
    my_file<<mingpa<<endl;
    my_file<<" Average GPA: ";
    my_file<<avergegpa/count1<<endl;



    my_file<<" The overall average GPA for all students is ";
    my_file<< avergegpa/count1;
    my_file<<" indicating a generally good level of academic achievement across the student body.";
    my_file<<" Compared to the previous semester, there has been a slight improvement in the average GPA,";
    my_file<<" reflecting the effectiveness of the academic support programs implemented.\n\n";

    my_file<<"---------------------------- Conclusion --------------------------------\n\n";
    my_file<<" In summary, the spring 2024 semester saw strong academic performances\n";
    my_file<<" with a maximum GPA of";
    my_file<<maxgpa;
    my_file<<" , a lowest GPA of";
    my_file<<mingpa<<endl;
    my_file<<" , and an average GPA of ";
    my_file<< avergegpa/count1<<endl;
    my_file<<" The majority of students performed well, with targeted support provided to those in need.\n";
    my_file<<" Continued focus on academic excellence and support services is recommended to maintain \n";
    my_file<<" and improve these results.\n";
    my_file.close();
    cout<<" The is generated and write in the file:"<<endl;

}

void displyreport()
{
    // open a text file for reading
    ifstream my_file("report.txt");
// check the file for errors
    if(!my_file)
    {
        cout << "Error: Unable to open the file." << endl;
        return ;
    }
// store the contents of the file in "line" string
    string line;
// loop until the end of the text file
    while (!my_file.eof())
    {
// store the current line of the file
// in the "line" variable
        getline(my_file, line);
// print the line variable
        cout << line << endl;
    }
// close the file
    my_file.close();

}


void displayforStudent()
{

    ifstream inFile("outFile.csv");
    if (!inFile.is_open())
    {
        cout << "Error: Unable to open the file." << endl;
        return;
    }

    string line;
    int num1;

    // Prompt user for ID input
    cout << "Enter the student ID:";
    cin >> num1;

    bool found = false;

    // Reset file stream to the beginning
    inFile.clear(); // Clear any error flags // help form google
    inFile.seekg(0, ios::beg); // Move to the beginning of the file

    // Read each line from the file
    while (getline(inFile, line))
    {
        stringstream ss(line);
        string id, name, age, QCR, ENA, FE, PHY, CIVIC, DF, total, percentage, grade, gpa;

        getline(ss, id, ',');
        getline(ss, name, ',');
        getline(ss, age, ',');
        getline(ss, QCR, ',');
        getline(ss, ENA, ',');
        getline(ss, FE, ',');
        getline(ss, PHY, ',');
        getline(ss, CIVIC, ',');
        getline(ss, DF, ',');
        getline(ss, total, ',');
        getline(ss, percentage, ',');
        getline(ss, grade, ',');
        getline(ss, gpa, ',');

        // Convert id from string to integer for comparison
        int studentID = stoi(id);

        // Check if the current student ID matches the input ID
        if (num1 == studentID)
        {
            cout << endl;
            cout << "--------------------  your result  --------------------" << endl;
            cout << endl;
            cout << "ID: " << id << endl;
            cout << "Name: " << name << endl;
            cout << "Age: " << age << endl;
            cout << "QCR: " << QCR << endl;
            cout << "ENA: " << ENA << endl;
            cout << "FE: " << FE << endl;
            cout << "PHY: " << PHY << endl;
            cout << "CIVIC: " << CIVIC << endl;
            cout << "DF: " << DF << endl;
            cout << "Total: " << total << endl;
            cout << "Percentage: " << percentage << endl;
            cout << "Grade: " << grade << endl;
            cout << "GPA: " << gpa << endl;
            cout<< endl;
            cout << "------------------------------------------------------" << endl;
            cout<< endl;

            found = true;
            break; // Stop searching after finding the student
        }
    }

    if (!found)
    {
        cout << "No student found with ID: " << num1 << endl;
    }



}

int main()
{
    cout << "****Student Management System****\n" << endl;
    int slect;
    cout << "Enter...1.... if you are admin:" << endl;
    cout << "Enter...2.... if you are student:" << endl;
    cin >> slect;
    cin.ignore(); // Clear the newline character from the input buffer

    if (slect == 1)
    {
        string nameadmin; // Enter the name of admin
        string password;

        cout << "Enter the your name: ";
        getline(cin, nameadmin); // Enter name of admin
        cout << "Enter the password: ";
        getline(cin, password); // Enter the password

        if (nameadmin == "raheem" && password == "namal123")   // Condition to check password and name is correct or not
        {
            ofstream outFile("outFile.csv", ios::app); // Open file in append mode

            if (!outFile)   // To check if file is open or not
            {
                cout << "Error: Unable to open the file." << endl;
                return 1;
            }

            while (true)   // Loop for repetition of condition
            {
                displayMenu(); // Function to call the display menu
                int choice;
                cin >> choice;
                cin.ignore(); // Clear the newline character from the input buffer

                Student newStudent; // Declare the variable of structure

                if (choice == 1)   // Conditional statement to compare the input
                {
                    ofstream outFile("outFile.csv", ios::app); // Open file in append mode

                    if (!outFile)   // To check if file is open or not
                    {
                        cout << "Error: Unable to open the file." << endl;
                        return 1;
                    }
                    addStudent(newStudent, outFile); // Function call to add student
                }
                else if (choice == 2)
                {
                    calculateStudentGPA(newStudent); // Function to calculate GPA
                }
                else if (choice == 3)
                {
                    displayStudents(); // Display data on the console output
                }
                else if (choice == 4)
                {
                    gernatereport(); // Function call to generate report
                }
                else if (choice == 5)
                {
                    displyreport(); // Display generated report on console output
                }
                else if (choice == 6)
                {
                    displayStudentsid(); // Display data on the console output
                }
                else if (choice == 7)
                {
                    cout << "Exiting the program." << endl;
                    return 0;
                }
                else
                {
                    cout << "Invalid choice. Please try again." << endl;
                }
            }
        }
        else
        {
            cout << "Incorrect username or password." << endl;
        }
    }
    else if (slect == 2)
    {
        cout << "For result enter .....3....:\n";
        cout << "Enter....4.... to exit:\n";
        int num2 = 0;
        cin >> num2;
        if (num2 == 3)
        {
            displayforStudent();
        }
        else if (num2 == 4)
        {
            cout << "Thank you for visiting.\n";
        }
    }
    return 0;

}
